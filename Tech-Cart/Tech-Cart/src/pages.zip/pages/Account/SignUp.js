import React, { useState } from "react";
import { Link } from "react-router-dom";
import { logoLight } from "../../assets/images";
import axios from "axios"; // Import Axios for making HTTP requests

const SignUp = () => {
  const [clientName, setClientName] = useState("");
  const [email, setEmail] = useState("");
  const [checked, setChecked] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errClientName, setErrClientName] = useState("");
  const [errEmail, setErrEmail] = useState("");

  const handleName = (e) => {
    setClientName(e.target.value);
    setErrClientName("");
  };

  const handleEmail = (e) => {
    setEmail(e.target.value);
    setErrEmail("");
  };

  const handleSignUp = (e) => {
    e.preventDefault();
    if (checked) {
      // Validation logic
      if (!clientName) {
        setErrClientName("Enter your name");
      }
      if (!email) {
        setErrEmail("Enter your email");
      }

      // If validation passes
      if (clientName && email) {
        // Call backend endpoint to send welcome email
        axios.post("/api/send-welcome-email", {
          clientName,
          email
        })
        .then(response => {
          setSuccessMsg(`Welcome email sent to ${email}`);
          setClientName("");
          setEmail("");
        })
        .catch(error => {
          console.error("Error sending welcome email:", error);
          // Handle error
        });
      }
    }
  };

  return (
    <div>
      <h1>Sign Up</h1>
      {successMsg && <p>{successMsg}</p>}
      <form onSubmit={handleSignUp}>
        <input type="text" value={clientName} onChange={handleName} placeholder="Name" />
        {errClientName && <p>{errClientName}</p>}
        <input type="email" value={email} onChange={handleEmail} placeholder="Email" />
        {errEmail && <p>{errEmail}</p>}
        <label>
          <input type="checkbox" checked={checked} onChange={() => setChecked(!checked)} />
          I agree to the terms and conditions
        </label>
        <button type="submit">Sign Up</button>
      </form>
      <Link to="/signin">Sign In</Link>
    </div>
  );
};

export default SignUp;
